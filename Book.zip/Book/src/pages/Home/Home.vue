<template>
  <div>
    <homeheader></homeheader>
    <home-swiper></home-swiper>
    <detail :movie="movie"></detail>
    <tap-bar></tap-bar>
  </div>
</template>
<script>
import Homeheader from './component/Homeheader.vue'
import HomeSwiper from './component/Swiper.vue'
import detail from './component/detail.vue'
import TapBar from './component/Tapbar.vue'
import axios from 'axios'
export default {
  name: 'home',
  data () {
    return {
      'movie': []
    }
  },
  components: {
    Homeheader,
    HomeSwiper,
    detail,
    TapBar
  },
  created () {
    this.getLocation()
  },
  methods: {
    getLocation () {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(this.showPosition)
      } else {
        alert('该浏览器不支持获取地理位置')
      }
    },
    showPosition (position) {
      this.$store.state.lat = position.coords.latitude
      this.$store.state.lag = position.coords.longitude
    },
    getHomeInfo () {
      axios.get('/static/mock/index.json').then(this.getHomeInfoSucc)
    },
    getHomeInfoSucc (e) {
      e = e.data
      if (e.ret && e.data) {
        const data = e.data
        this.movie = data.movie
      }
    }
  },
  mounted () {
    this.getHomeInfo()
  }
}
</script>
<style scoped>
</style>
