<template>
  <div>
    <div class="header">
      <router-link to="/city">
    <div class="header-left" >
      <img class="logoSize" src="../../../assets/logo.png" height="30" width="30"/>
      {{this.$store.state.city}}
      <span class="iconfont logo">&#xe771;</span>
    </div>
      </router-link>
    <div class="header-right">
      <div class="header-left-box">即将上映</div>
      <div class="border-right-box">正在热映</div>
    </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Home-header'
}
</script>
<style scoped>
  .header{
    height: .80rem;
  }
  .header-left{
    float: left;
    line-height: .8rem;
    padding-left: 0.5rem;
    color: #8a8a8a;
  }
  .header-right{
    float: right;
    line-height: .8rem;
    padding-right: 1.2rem;
    color: #8a8a8a;
  }
  .header-left-box{
    float: right;
  }
  .border-right-box{
    float: right;
    padding-right: .5rem;
    color: red;
  }
  .logo{
    font-size: .1rem;
  }
</style>
