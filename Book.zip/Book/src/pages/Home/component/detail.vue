<template>
  <div>
  <div  v-for="item in movie" :key="item.id">
   <div class="m-item"></div>
   <div class="m-wrap">
     <div class="m-info">
       <div class="poster">
         <img :src="item.img">
       </div>
       <div class="m-item-content">
         <div class="title">{{item.name}}</div>
         <div class="brief">
           <div>观众评分</div>
           <span class="txt-warning">{{item.number}}</span>
         </div>
         <div class="brief">导演：{{item.direction}}</div>
         <div class="brief">主演：{{item.taring}}</div>
         <div class="fantastic">
           <div class="fantastic-left">今日最热</div>
           <div class="fantastic-right">一周最热</div>
         </div>
       </div>
       <div class="btn-wrap"
            @click="getMovie(item.name)">
         <router-link to="/Cinema">
         <div class="btn-wrap-top">购票</div>
         </router-link>
       </div>
     </div>
   </div>
  </div>
  </div>
</template>
<script>
export default {
  name: 'detail',
  props: {
    movie: Array
  },
  methods: {
    getMovie (res) {
      this.$store.state.movie = res
    }
  }
}
</script>
<style scoped>
  .m-item{
    float: left;
    width: 5%;
    height: 0;
    padding-bottom: 40%;
  }
  .m-wrap{
    position: relative;
    width: 100%;
    height: 0;
    padding-bottom: 40%;
  }
  .m-info{
    float: left;
    width: 95%;
    height: 0;
    padding-bottom: 40%;
    border-bottom: 1px solid #eaeaea;
  }
  .poster img {
    position: absolute;top:10%;
    width: 20%;
    height: auto;
    max-width: 100%;
    display: block;
  }
  .m-item-content{
    position: absolute;top:10%;left: 30%;
  }
  .title{
    width: 100%;
    height: 0;
    padding-bottom: 10%;
    line-height: 20px;
    font-size: .32rem;
    font-weight: 400;
    color: black;
  }
  .brief{
    width: 100%;
    height: 0;
    padding-bottom: 10%;
    margin-top: 2%;
    color:#8a8a8a;
    line-height: 20px;
  }
  .txt-warning{
    position: absolute;left: 30%;top: 20%;
    color:orange;
  }
  .fantastic{
    width: 100%;
    height: 0;
    padding-bottom: 12%;
    margin-top: 2%;
    line-height: 18px;
    font-size: 10px;
    text-align: center;
  }
  .fantastic-left{
    width: 50px;
    height: 16px;
    float: left;
    color: red;
    border: 1px solid red;
  }
  .fantastic-right{
    width: 50px;
    height: 16px;
    float: left;
    color: orange;
    margin-left: 2%;
    border: 1px solid orange;
  }
  .btn-wrap{
    position: absolute;right: 5%;
    width: 13%;
    height: 0;
    padding-bottom: 42%;
    font-size: 10px;
  }
  .btn-wrap-top{
    position: absolute;top: 28%;
    width: 50px;
    height: 28px;
    background-color:#ff7ba0;
    color: white;
    text-align: center;
    line-height: 28px;
    border-radius: 25px;
  }
</style>
