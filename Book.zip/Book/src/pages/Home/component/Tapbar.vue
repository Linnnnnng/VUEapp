<template>
  <div class="Tap">
    <div class="bottom-box  color">
      <span class="iconfont logo">&#xe67e;</span>
      <div>热映</div>
  </div>
    <div class="bottom-box">
      <router-link to="/Cinema">
      <span class="iconfont logo to">&#xe61d;</span>
      <div class="to">影院</div>
      </router-link>
    </div>
    <div class="bottom-box">
      <span class="iconfont logo">&#xe75c;</span>
      <div>我的</div>
      </div>
  </div>
</template>
<script>
export default {
  name: 'TapBar'
}
</script>
<style scoped>
  .Tap{
    display: flex;
    position: fixed;
    bottom:0;
    width: 100%;
    height:0;
    padding-bottom: 13%;
    background-color: white;
    opacity: 0.9;
  }
  .bottom-box{
    width: 33.3%;
    height: 0;
    padding-bottom: 13%;
    text-align: center;
  }
  .logo{
    font-size:200%;
  }
  .color{
    color: red;
  }
  .to{
    color: black;
  }
</style>
