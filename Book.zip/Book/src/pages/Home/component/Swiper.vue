<template>
  <div class="aa">
    <swiper :options="swiperOption">
      <swiper-slide>
        <img class="img" src="//gw.alicdn.com/tfs/TB1pgHBai6guuRjy1XdXXaAwpXa-1280-520.jpg_720x720Q30s100.jpg">
      </swiper-slide>
      <swiper-slide>
        <img class="img" src="//gw.alicdn.com/tfs/TB1d5_rGx9YBuNjy0FfXXXIsVXa-1280-520.jpg_720x720Q30s100.jpg">
      </swiper-slide>
      <swiper-slide>
        <img class="img" src="//gw.alicdn.com/tfs/TB1lah6JNGYBuNjy0FnXXX5lpXa-1280-520.jpg_720x720Q30s100.jpg">
      </swiper-slide>
      <swiper-slide>
        <img class="img" src="//gw.alicdn.com/tfs/TB1F4rFJAyWBuNjy0FpXXassXXa-1280-520.jpg_720x720Q30s100.jpg">
      </swiper-slide>
      <div class="swiper-pagination"  slot="pagination"></div>
    </swiper>
  </div>
</template>
<script>
export default {
  name: 'HomeSwiper',
  data () {
    return {
      swiperOption: {
        pagination: '.swiper-pagination',
        autoplay: 2000,
        loop: 'true'
      }
    }
  }
}
</script>
<style scoped>

  .aa >>> .swiper-pagination-bullet{
    background: white;
    border-radius: 0;
    size: 1px;
    width: 5px;
    height: 5px;
  }

  .aa{
    overflow: hidden;
    width: 100%;
    height: 0;
    padding-bottom: 40%

  }
  .img{
    width: 100%;
  }
</style>
