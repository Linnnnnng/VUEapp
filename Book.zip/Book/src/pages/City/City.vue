<template>
  <div>
    <cityheader></cityheader>
    <search :cities="cities"></search>
    <list :hot="hotCities" :cities="cities" :letter="letter" :text="text"></list>
    <alphabet :cities="cities" @change="handleLetterChange"
              @TextChange="handleTextChange"
    ></alphabet>
  </div>
</template>
<script>
import Cityheader from './component/Cityheader.vue'
import List from './component/List.vue'
import Alphabet from './component/Alphabet.vue'
import Search from './component/Search.vue'
import axios from 'axios'
export default {
  name: 'city',
  data () {
    return {
      hotCities: [],
      cities: {},
      letter: '',
      text: ''
    }
  },
  components: {
    Cityheader,
    List,
    Alphabet,
    Search
  },
  methods: {
    getCityInfo () {
      axios.get('/static/mock/city.json').then(this.getCityInfoSucc)
    },
    getCityInfoSucc (res) {
      res = res.data
      if (res.ret && res.data) {
        const data = res.data
        this.hotCities = data.hotCities
        this.cities = data.cities
      }
    },
    handleLetterChange (e) {
      this.letter = e
    },
    handleTextChange (e) {
      this.text = e
    }
  },
  mounted () {
    this.getCityInfo()
  }
}
</script>
