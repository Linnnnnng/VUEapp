<template>
  <div class="city-title">
    选择城市
    <router-link to="/">
      <span class="iconfont btn-close">&#xe624;</span>
    </router-link>
  </div>
</template>
<script>
export default {
  name: 'CityHeader'
}
</script>
<style scoped>
  .city-title{
    float: right;
    width: 100%;
    height:0;
    padding-bottom:12%;
    font-size: .32rem;
    text-align: center;
    line-height: 45px;
  }
  .btn-close{
    position: absolute;right: 0;
    z-index: 2;
    width:12% ;
    height:0;
    font-size: .3rem;
    padding-bottom: 12%;
    color: black;
  }
</style>
