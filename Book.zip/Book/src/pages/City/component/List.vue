<template>
  <div class="list" ref="wrapper">
    <div>
    <div class="list-title" ref="当前">当前</div>
     <div class="list-item">{{this.$store.state.city}}</div>
      <div class="list-title" ref="GPS">GPS</div>
      <router-link to="/map">
      <div class="list-item">定位城市</div>
      </router-link>
    <div class="list-title"  ref="热门">热门</div>
     <div class="list-item" v-for="item in hot" :key="item.id"
      @click="handleCityClick(item.name)">
       {{item.name}}</div>
      <div v-for="(item , key) in cities" :key="key" :ref="key">
    <div class="list-title">{{key}}</div>
     <div class="list-item" v-for="innerItem in item" :key="innerItem.id"
          @click="handleCityClick(innerItem.name)"
     >{{innerItem.name}}</div>
      </div>
    </div>
  </div>
</template>
<script>
import Bscroll from 'better-scroll'
export default {
  name: 'List',
  data () {
    return {
      city: '广州'
    }
  },
  props: {
    hot: Array,
    cities: Object,
    letter: String,
    text: String
  },
  methods: {
    handleCityClick (res) {
      this.$store.state.city = res
      this.$router.push('/')
    }
  },
  mounted () {
    this.scroll = new Bscroll(this.$refs.wrapper, {click: true})
  },
  watch: {
    letter () {
      if (this.letter) {
        const element = this.$refs[this.letter]
        this.scroll.scrollToElement(element[0])
      }
    },
    text () {
      if (this.text) {
        const element = this.$refs[this.text]
        this.scroll.scrollToElement(element)
      }
    }
  }
}
</script>
<style scoped>
  .list-title{
    width: 100%;
    height: 0;
    line-height: 36px;
    padding-bottom: 10%;
    padding-left: 10px;
    background-color: #eaeaea;
    color: #8a8a8a;
    font-size: 10px;
  }
  .list-item{
    width: 100%;
    height: 0;
    line-height: 46px;
    padding-bottom: 12%;
    padding-left: 15px;
    color: #8a8a8a;
    border-bottom: 1px solid #eaeaea;
  }
  .list{
    overflow: hidden;
    position: absolute;
    top: 2rem;
    left: 0;
    right: 0;
    bottom: 0

  }
</style>
