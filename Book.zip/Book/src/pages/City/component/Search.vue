<template>
  <div>
    <input v-model="keyword" class="search-input" type="text" placeholder="请输入你要搜索的城市" />
    <div class="search-content" v-show="keyword">
      <div class="search-list" v-for="item in list" :key="item.id"
      @click="handleCityClick(item.name)"
      >{{item.name}}</div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Search',
  props: {
    cities: Object
  },
  data () {
    return {
      keyword: '',
      list: []
    }
  },
  watch: {
    keyword () {
      const result = []
      for (let i in this.cities) {
        this.cities[i].forEach((value) => {
          if (value.spell.indexOf(this.keyword) > -1 || value.name.indexOf(this.keyword) > -1) {
            result.push(value)
          }
        })
      }
      this.list = result
    }
  },
  methods: {
    handleCityClick (city) {
      this.$store.state.city = city
      this.$router.push('/')
    }
  }
}
</script>
<style scoped>
  .search-input{
    box-sizing: border-box;
    width:100%;
    height: 1rem;
    padding:.2rem;
    border-radius: .06rem;
    text-align: center;
    font-size:10px;
    border-top: 20px solid #eaeaea;
  }
  .search-content{
    position: absolute;
    z-index: 100;
    width:100%;
    height: 0;
    padding-bottom:200%;
    background-color: white;
  }
  .search-list{
    width: 100%;
    height: 0;
    line-height: 46px;
    padding-bottom: 12%;
    padding-left: 15px;
    color: #8a8a8a;
    border-bottom: 1px solid #eaeaea;
  }
  input:focus::-webkit-input-placeholder{
    text-indent: -999em;
    z-index: -20
  }
</style>
