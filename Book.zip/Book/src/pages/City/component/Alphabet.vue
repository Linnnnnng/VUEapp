<template>
  <div>
  <div class="A-Z">
    <div @click="handleTextClick">
    <div class="box">当前</div>
    <div class="box">GPS</div>
    <div class="box">热门</div>
    </div>
    <div class="box" v-for="(item, key) in cities" :key="key"
         @click="handleLetterClick"
    >{{key}}</div>
  </div>
  </div>
</template>
<script>
export default {
  name: 'Alphabet',
  props: {
    cities: {}
  },
  methods: {
    handleLetterClick (e) {
      this.$emit('change', e.target.innerHTML)
    },
    handleTextClick (e) {
      this.$emit('TextChange', e.target.innerHTML)
    }
  }
}
</script>
<style scoped>
  .A-Z{
    display: flex;
    position:absolute;right: 0;top: 14%;
    flex-direction: column;
    z-index: 99;
    width: 10%;
    height: 0;
    padding-bottom: 110%;
  }
  .box{
    width: 100%;
    height: 0;
    padding-bottom: 50%;
    line-height: 20px;
    text-align: center;
    font-size: 10px;
    color:deepskyblue;
  }
</style>
