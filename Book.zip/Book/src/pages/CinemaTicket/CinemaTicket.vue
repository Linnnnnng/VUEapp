<template>
  <div>
    <cinema-ticket-header></cinema-ticket-header>
  </div>
</template>
<script>
import CinemaTicketHeader from './component/CinemaTicketHeader.vue'
export default {
  name: 'CinemaTicket',
  components: {
    CinemaTicketHeader
  }
}
</script>
<style scoped>
</style>
