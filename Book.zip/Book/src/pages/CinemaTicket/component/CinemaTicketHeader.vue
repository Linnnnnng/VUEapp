<template>
  <div>
    <div class="TicketHeader">
      <div class="TicketHeader-Text">
    <div class="TicketHeader-Text-Top">{{this.$store.state.cinema}}</div>
    <div class="TicketHeader-Text-bottom">{{this.$store.state.location}}</div>
      </div>
      <router-link to="/">
        <div class="back">返回</div>
      </router-link>
    </div>
  </div>
</template>
<script>
export default {
  name: 'CinemaTicketHeader'
}
</script>
<style scoped>
  .TicketHeader{
    width: 100%;
    height: 0;
    padding-bottom: 20%;
  }
  .TicketHeader-Text{
    float: left;
    width: 100%;
    height: 0;
    margin-left: 5%;
    padding-bottom: 10%;
    line-height: 37px;
  }
  .TicketHeader-Text-Top{
    font-weight:400;
    font-size: 17px;
  }
  .TicketHeader-Text-bottom{
    font-size: 10px;
    color: #8a8a8a;
  }
  .back {
    color: black;
    float: right;
  }
</style>
