<template>
  <div>
    <detail></detail>
    <map-header></map-header>
  </div>
</template>
<script>
import detail from './component/detail.vue'
import MapHeader from './component/Mapheader.vue'
export default {
  name: 'Map',
  components: {
    detail,
    MapHeader
  }
}
</script>
<style>
</style>
