<template>
  <div>
  <div class="text">
    你当前的位置
    <router-link to="/city">
    <span class="iconfont back">&#xe624;</span>
    </router-link>
  </div>
  </div>
</template>
<script>
export default {
  name: 'MapHeader'
}
</script>
<style scoped>
  .text{
    float: right;
    width: 100%;
    height:0;
    padding-bottom:12%;
    font-size: .32rem;
    text-align: center;
    line-height: 45px;
  }
  .back{
    position: absolute;right: 0;
    z-index: 2;
    width:12% ;
    height:0;
    font-size: .3rem;
    padding-bottom: 12%;
    color: black;
  }
</style>
