<template>
  <div>
    <div id="allmap" class="map">
    </div>
  </div>
</template>
<script>
import BMap from 'BMap'
export default {
  name: 'detail',
  mounted () {
    this.baiduMap()
  },
  methods: {
    baiduMap () {
      const map = new BMap.Map('allmap')
      const point = new BMap.Point(this.$store.state.lag, this.$store.state.lat)
      map.centerAndZoom(this.$store.state.city, 12)
      const marker = new BMap.Marker(point)
      map.addOverlay(marker)
    }
  }
}
</script>
<style>
  .map{
    position: absolute;top: 7%;
    width: 100%;
    height: 0;
    padding-bottom: 200%;
  }
</style>
