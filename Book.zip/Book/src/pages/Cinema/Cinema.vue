<template>
  <div>
    <cinema-header :ChangeRegion="ChangeRegion"></cinema-header>
    <cinema-detail :cinema="cinema"></cinema-detail>
    <cinema-tapbar></cinema-tapbar>
  </div>
</template>
<script>
import CinemaHeader from './component/CinemaHeader.vue'
import CinemaDetail from './component/CinemaDetail.vue'
import CinemaTapbar from './component/CinemaTapbar.vue'
import axios from 'axios'
export default {
  name: 'Cinema',
  data () {
    return {
      cinema: {},
      ChangeRegion: []
    }
  },
  components: {
    CinemaHeader,
    CinemaDetail,
    CinemaTapbar
  },
  methods: {
    getCinemaInfo () {
      if (this.$store.state.city === '广州') {
        axios.get('/static/mock/gz_cinema.json').then(this.getCinemaInfoSucc)
      } else {
        alert('抱歉，没有找到该城市')
      }
    },
    getCinemaInfoSucc (res) {
      res = res.data
      if (res.data) {
        const element = res.data
        this.cinema = element.returnValue.regionCinemas
        this.ChangeRegion = element.returnValue.regionOrder
      }
    }
  },
  mounted () {
    this.getCinemaInfo()
  }
}
</script>
<style scoped></style>
