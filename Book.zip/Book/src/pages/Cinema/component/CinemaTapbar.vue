<template>
  <div class="Tap">
    <div class="bottom-box">
      <router-link to="/">
      <span class="iconfont logo to">&#xe67e;</span>
      <div class="to">热映</div>
      </router-link>
    </div>
    <div class="bottom-box color">
        <span class="iconfont logo">&#xe61d;</span>
        <div>影院</div>
    </div>
    <div class="bottom-box">
      <span class="iconfont logo">&#xe75c;</span>
      <div>我的</div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'CinemaTapBar'
}
</script>
<style scoped>
  .Tap{
    display: flex;
    position: fixed;
    bottom:0;
    width: 100%;
    height:0;
    padding-bottom: 13%;
    background-color: white;
    opacity: 0.9;
  }
  .bottom-box{
    width: 33.3%;
    height: 0;
    padding-bottom: 13%;
    text-align: center;
  }
  .logo{
    font-size:200%;
  }
  .color{
    color: red;
  }
  .to{
    color: black;
  }
</style>
