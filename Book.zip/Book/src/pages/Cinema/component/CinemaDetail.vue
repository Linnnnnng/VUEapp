<template>
  <div>
    <router-link to="/CinemaTicket">
  <div class="list"  v-for="item in cinema[this.$store.state.region]" :key="item.id">
    <div class="list-item"  @click="cinemaCity(item.cinemaName, item.address)">
    <div class="list-title item" >
      <div class="list-title-left ">{{item.cinemaName}}</div>
      <div class="list-title-right color">{{item.availableTodayScheduleCount}}元起</div>
    </div>
    <div class="list-location item">{{item.address}}</div>
    </div>
  </div>
    </router-link>
  </div>
</template>
<script>
export default {
  name: 'CinemaDetail',
  props: {
    cinema: Object
  },
  methods: {
    cinemaCity (res, e) {
      this.$store.state.cinema = res
      this.$store.state.location = e
    }
  }
}
</script>
<style scoped>
  .list{
    width: 100%;
    height: 0;
    padding-bottom: 24%;
    border-bottom: 1px solid #eaeaea;
  }
  .item {
    float: left;
    width: 100%;
    height: 0;
    padding-bottom: 10%;
  }
  .list-item {
    padding: 2% 4%;
    line-height: 38px;
    border-bottom: 0;
  }
  .list-title-left{
    float: left;
    width: 60%;
    height: 0;
    padding-bottom: 10%;
    font-size: 0.35rem;
    font-weight: 500;
    white-space: nowrap;
    text-overflow : ellipsis;
    overflow: hidden;
    color: black;
  }
  .list-title-right{
    float: right;
  }
  .list-location{
    color: #8a8a8a;
    white-space: nowrap;
    text-overflow : ellipsis;
    overflow: hidden
  }
  .color{
    color: red;
  }
</style>
