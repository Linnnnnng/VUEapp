<template>
  <div>
  <div class="fix">
    <div class="real-header"></div>
    <div class="header">
      <router-link to="/city">
        <img class="logoSize" src="../../../assets/logo.png" height="30" width="30"/>
        <div class="header-left" >
          {{this.$store.state.city}}
          <span class="iconfont logo">&#xe771;</span>
        </div>
      </router-link>
      <div class="region"
           @click="ShowCity"
           :class="{ changeShow : this.show }"
      >{{this.newCity}}
        <span class="iconfont logo"
        >&#xe771;</span>
      </div>
    </div>
    <div v-if="show">
      <div class="CityRegion">
      <div class="box" v-for="item in ChangeRegion" :key="item.id"
     @click="region(item)"
      >
        {{item}}
      </div>
        <div  class="selector"></div>
      </div>
    </div>
  </div>
  </div>
</template>
<script>
export default {
  name: 'CinemaHeader',
  data () {
    return {
      newCity: '区域',
      show: false
    }
  },
  props: {
    ChangeRegion: Array
  },
  methods: {
    region (res) {
      this.$store.state.region = res
      this.newCity = res
      this.show = !this.show
    },
    ShowCity () {
      this.show = !this.show
    }
  }
}
</script>
<style scoped>
  .header{
    width: 100%;
    height: 0;
    padding-bottom: 15%;
    border-bottom: 1px solid #eaeaea;
    background-color: white;
    position: fixed;
    margin-top: -15%;
  }
  .header-left{
    position: absolute;left: 15%;top:40%;
    color: #8a8a8a;
  }
  .region{
    float: right;
    position: absolute;top: 40%;right: 15%;
    color: #8a8a8a;
  }
 .logo{
    font-size: .1rem;
  }
  .CityRegion{
    width: 100%;
    height: 0;
    padding-bottom: 40%;
    background-color: white;
    position: fixed;
  }
  .box{
    float: left;
    width: 20%;
    height: 0;
    padding-bottom: 8%;
    margin-left: 13px;
    margin-bottom: 20px;
    border: 1px solid #eaeaea;
    text-align: center;
    line-height: 180%;
  }
  .selector{
    position: fixed;
    z-index: 20;
    width: 100%;
    height: 0;
    margin-top: 40%;
    padding-bottom: 150%;
    background-color:black;
    opacity: 0.5;
  }
  .real-header{
    width: 100%;
    height: 0;
    padding-bottom: 15%
  }
  .logoSize{
    padding-left: 6%;
    padding-top: 4%;
  }
  .changeShow {
    color: red;
  }
</style>
