import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/pages/Home/Home'
import City from '@/pages/City/City'
import Map from '@/pages/Map/Map'
import Cinema from '@/pages/Cinema/Cinema'
import CinemaTicket from '@/pages/CinemaTicket/CinemaTicket'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/city',
      name: 'City',
      component: City
    },
    {
      path: '/map',
      name: 'Map',
      component: Map
    },
    {
      path: '/Cinema',
      name: 'Cinema',
      component: Cinema
    },
    {
      path: '/CinemaTicket',
      name: 'CinemaTicket',
      component: CinemaTicket
    }
  ]
})
