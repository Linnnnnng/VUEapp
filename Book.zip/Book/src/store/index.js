import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    city: '广州',
    lat: '',
    lag: '',
    region: '白云区',
    movie: '',
    cinema: '',
    location: ''
  }
})
